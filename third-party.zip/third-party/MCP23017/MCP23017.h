#pragma once
//
//    FILE: MCP23017.h
//  AUTHOR: Rob Tillaart
// VERSION: 0.9.1
// PURPOSE: Arduino library for I2C MCP23017 16 channel port expander
//    DATE: 2019-10-12
//     URL: https://github.com/RobTillaart/MCP23017_RT
//
// WARNING: please read REV D note in readme.md
//          about pin 7 and 15 and INPUT mode.


#include "Arduino.h"
#include "Wire.h"
#include "MCP23x17_registers.h"

#define MCP23017_OK                       0x00
#define MCP23017_PIN_ERROR                0x81
#define MCP23017_I2C_ERROR                0x82
#define MCP23017_VALUE_ERROR              0x83
#define MCP23017_PORT_ERROR               0x84
#define MCP23017_REGISTER_ERROR           0xFF
#define MCP23017_INVALID_READ             0xFF


class MCP23017
{
public:
  MCP23017(uint8_t address, TwoWire *wire = &Wire);

  bool     begin(bool pullup = true);
  bool     isConnected();
  uint8_t  getAddress();

  //       Patch #46
  void     setAddress(uint8_t address) { _address = address; };
  void     setWire(TwoWire *wire) {_wire = wire; };


  //       Fix #44, reverse the byte order of the 16 bit API.
  //       reverse == false ==> backwards compatible (default)
  //       reverse == true ==> swaps the A and B byte to be more intuitive.
  void     reverse16ByteOrder(bool reverse = false);

  //       single pin interface
  //       mode = INPUT, OUTPUT, INPUT_PULLUP (= same as INPUT)
  //             do not use 0, 1 for mode.
  //       See readme.md section REV D
  bool     pinMode1(uint8_t pin, uint8_t mode);
  bool     write1(uint8_t pin, uint8_t value);
  uint8_t  read1(uint8_t pin);

  //       8 pins interface
  //       port  = 0..1
  //       mask  = 0x00..0xFF  bit pattern,
  //               bit 0 = output mode, bit 1 = input mode
  //       value = bit pattern.
  bool     pinMode8(uint8_t port, uint8_t mask);
  bool     write8(uint8_t port, uint8_t value);
  int      read8(uint8_t port);

  //       16 pins interface
  //       mask = 0x0000..0xFFFF bit pattern
  //              bit 0 = output mode, bit 1 = input mode
  //       value = bit pattern.
  bool     pinMode16(uint16_t mask);
  bool     write16(uint16_t value);
  uint16_t read16();

  //       debugging
  int      lastError();

  //       set/clear IOCR bit fields
  bool     enableControlRegister(uint8_t mask);
  bool     disableControlRegister(uint8_t mask);


protected:
  //       access to low level registers (just make these functions public).
  //       USE WITH CARE !!!
  bool     writeReg(uint8_t reg, uint8_t value);
  uint8_t  readReg(uint8_t reg);
  bool     writeReg16(uint8_t reg, uint16_t value);
  uint16_t readReg16(uint8_t reg);

  bool     _reverse16ByteOrder = false;

  uint8_t   _address;
  TwoWire*  _wire;
  uint8_t   _error;
};


/*
TODO
- can it protect the user
- can we detect REV D chips (over I2C)

class MCP23017_REVD : public MCP23017
{
public:
  MCP23017_REVD(uint8_t address, TwoWire *wire = &Wire);

- GPA7 and GPB7 should be set to output in constructor
- GPA7 and GPB7 output mode may not change in any call
- GPA7 and GPB7 should return last written value for read.
- which functions are affected?  setMode  pullups etc.

};
*/


//  -- END OF FILE --

